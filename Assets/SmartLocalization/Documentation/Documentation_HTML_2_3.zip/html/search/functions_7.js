var searchData=
[
  ['initialize',['Initialize',['../interface_smart_localization_1_1_editor_1_1_i_automatic_translator.html#a231ef7b1c1e48d097ad2feefd000cbbb',1,'SmartLocalization.Editor.IAutomaticTranslator.Initialize()'],['../class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html#ae2917d77fd865d4e5e3428c1e50e9198',1,'SmartLocalization.Editor.MicrosoftAutomaticTranslator.Initialize()']]],
  ['initializelanguage',['InitializeLanguage',['../class_smart_localization_1_1_editor_1_1_translate_language_window.html#af7b4b5dd2c5026d6d3e04c22d28b9910',1,'SmartLocalization::Editor::TranslateLanguageWindow']]],
  ['initializetranslatoreventhandler',['InitializeTranslatorEventHandler',['../namespace_smart_localization_1_1_editor.html#a7967d62f76e1c266127c9ed32c3ab402',1,'SmartLocalization::Editor']]],
  ['iscultureincollection',['IsCultureInCollection',['../class_smart_localization_1_1_smart_culture_info_collection.html#aeb2f439546a9fe1017c4f4fe18702168',1,'SmartLocalization::SmartCultureInfoCollection']]],
  ['islanguagesupported',['IsLanguageSupported',['../class_smart_localization_1_1_language_manager.html#a25a16c119e044e204e6737d3508b7cd4',1,'SmartLocalization.LanguageManager.IsLanguageSupported(string languageCode)'],['../class_smart_localization_1_1_language_manager.html#a9e7d3cc7672ce54a10f143aee63058bc',1,'SmartLocalization.LanguageManager.IsLanguageSupported(SmartCultureInfo cultureInfo)']]],
  ['islanguagesupportedenglishname',['IsLanguageSupportedEnglishName',['../class_smart_localization_1_1_language_manager.html#a59ec1cda84e06e5216e76374ff17a5d9',1,'SmartLocalization::LanguageManager']]]
];
