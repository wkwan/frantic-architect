package com.voxelbusters.nativeplugins.features.notification.core;

import org.json.JSONObject;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.utilities.Debug;

public class AlarmEventReceiver extends BroadcastReceiver
{
	public static String	EVENT_TYPE						= "EVENT_TYPE";
	public static String	DATA							= "DATA";
	public static String	ALARM_EVENT_FOR_NOTIFICATION	= "EVENT_FOR_NOTIFICATION";

	@Override
	public void onReceive(Context context, Intent intent)
	{
		try
		{
			Bundle info = intent.getExtras();
			String eventType = info.getString(EVENT_TYPE);

			Debug.log(CommonDefines.NOTIFICATION_TAG, "Received Alarm event " + info.toString());
			if (eventType.equals(ALARM_EVENT_FOR_NOTIFICATION))
			{
				//Use notification dispatcher to dispatch the notification. This can be a service
				String jsonData = info.getString(DATA);

				//Create a bundle and fill in here.
				JSONObject json = new JSONObject(jsonData);

				//Pass this to notification dispatcher
				NotificationDispatcher dispatcher = new NotificationDispatcher(context);
				dispatcher.dispatch(json, false);// Post the notification

			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			Debug.error(CommonDefines.NOTIFICATION_TAG, "Error on receiving Alarm notification");
		}
	}
}
