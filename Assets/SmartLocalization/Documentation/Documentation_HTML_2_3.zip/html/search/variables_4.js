var searchData=
[
  ['keytypeidentifier',['keyTypeIdentifier',['../class_smart_localization_1_1_localized_object.html#af720ac31ca097bf5a99da91ad7577aa2',1,'SmartLocalization::LocalizedObject']]]
];
