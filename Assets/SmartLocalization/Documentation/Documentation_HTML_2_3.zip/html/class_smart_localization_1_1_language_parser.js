var class_smart_localization_1_1_language_parser =
[
    [ "LoadLanguage", "class_smart_localization_1_1_language_parser.html#a5ea815dbae6a80442ffb60f86b213ec0", null ]
];