var class_smart_localization_1_1_editor_1_1_translate_language_window =
[
    [ "Initialize", "class_smart_localization_1_1_editor_1_1_translate_language_window.html#a722a751821dfa9358879eba669c17989", null ],
    [ "InitializeLanguage", "class_smart_localization_1_1_editor_1_1_translate_language_window.html#af7b4b5dd2c5026d6d3e04c22d28b9910", null ],
    [ "InitializeTranslator", "class_smart_localization_1_1_editor_1_1_translate_language_window.html#a98161d34ce07374718ae456e78fbf618", null ],
    [ "ReloadLanguage", "class_smart_localization_1_1_editor_1_1_translate_language_window.html#a767ba1b1ffa5b29e250960243eb0fdf7", null ],
    [ "ShowWindow", "class_smart_localization_1_1_editor_1_1_translate_language_window.html#a45d0e975899be5397de35d071f5ad390", null ],
    [ "automaticTranslator", "class_smart_localization_1_1_editor_1_1_translate_language_window.html#a64594a39177d1808af7a2886b12f4ba1", null ]
];