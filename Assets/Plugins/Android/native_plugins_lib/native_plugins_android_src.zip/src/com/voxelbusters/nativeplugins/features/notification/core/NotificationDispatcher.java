package com.voxelbusters.nativeplugins.features.notification.core;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.os.Build;
import android.support.v4.app.NotificationCompat;

import com.voxelbusters.NativeBinding;
import com.voxelbusters.androidnativeplugin.R;
import com.voxelbusters.nativeplugins.NativePluginHelper;
import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.defines.Keys;
import com.voxelbusters.nativeplugins.defines.UnityDefines;
import com.voxelbusters.nativeplugins.features.notification.NotificationHandler;
import com.voxelbusters.nativeplugins.features.notification.NotificationHandler.NotificationType;
import com.voxelbusters.nativeplugins.utilities.ApplicationUtility;
import com.voxelbusters.nativeplugins.utilities.Debug;
import com.voxelbusters.nativeplugins.utilities.JSONUtility;
import com.voxelbusters.nativeplugins.utilities.StringUtility;

public class NotificationDispatcher
{
	Context		context;
	MediaPlayer	mediaPlayer;

	public NotificationDispatcher(Context context)
	{
		this.context = context;
	}

	public void dispatch(JSONObject notificationData, boolean isRemoteNotification)
	{
		JSONObject keyMap = NotificationDefines.getKeysInfo(context);
		Debug.log(CommonDefines.NOTIFICATION_TAG, "Current keymapping used is " + keyMap.toString());

		Debug.log(CommonDefines.NOTIFICATION_TAG, "notificationData " + notificationData.toString());

		NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
		String appName = ApplicationUtility.getApplicationName(context);

		// If app is in foreground we don't need to push the notification in notification bar
		JSONObject formattedNotification = getFormattedNotification(notificationData, keyMap);
		String formattedNotificationString = formattedNotification.toString();

		boolean isAppRunning = NativePluginHelper.isApplicationRunning();
		boolean isAppForeground = NativeBinding.isApplicationForeground();

		if (!isAppRunning || !isAppForeground)
		{
			try
			{
				Intent notificationIntent = new Intent(context, ApplicationUtility.GetLauncherActivity(context));

				notificationIntent.putExtra(Keys.Notification.NOTIFICATION_PAYLOAD, formattedNotificationString);

				PendingIntent pendingIntent = PendingIntent.getActivity(context.getApplicationContext(), 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
				String contentTitle = notificationData.optString(keyMap.getString(NotificationDefines.CONTENT_TITLE), null);
				String contentText = notificationData.optString(keyMap.getString(NotificationDefines.CONTENT_TEXT), null);
				String tickerText = notificationData.optString(keyMap.getString(NotificationDefines.TICKER_TEXT), null);
				String notificationTag = notificationData.optString(keyMap.getString(NotificationDefines.TAG), null);

				String customSoundName = notificationData.optString(keyMap.getString(NotificationDefines.CUSTOM_SOUND), null);
				String largeIconName = notificationData.optString(keyMap.getString(NotificationDefines.LARGE_ICON), null);

				NotificationCompat.Builder builder = new NotificationCompat.Builder(context);
				builder.setDefaults(Notification.DEFAULT_LIGHTS | Notification.DEFAULT_VIBRATE);

				if (NotificationDefines.needsCustomIconDrawing(context))
				{
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
					{
						builder.setSmallIcon(R.drawable.app_icon_custom_white);
					}
					else
					{
						builder.setSmallIcon(R.drawable.app_icon_custom_coloured);
					}
				}
				else
				{
					builder.setSmallIcon(context.getApplicationInfo().icon);
				}

				//Set large icon now.
				Bitmap customLargeIcon = getCustomLargeIconBitmap(largeIconName);
				if (customLargeIcon != null)
				{
					builder.setLargeIcon(customLargeIcon);
				}

				builder.setWhen(System.currentTimeMillis());
				builder.setAutoCancel(true);
				builder.setContentIntent(pendingIntent);

				if (NotificationHandler.getInstance().hasNotificationType(NotificationType.Sound))
				{
					if (StringUtility.isNullOrEmpty(customSoundName))
					{
						builder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
					}
					else
					{
						PlayCustomNotificationSound(customSoundName);
					}
				}

				//builder.setNumber(badge); //TODO

				if (contentText != null)
				{
					if (NotificationHandler.getInstance().hasNotificationType(NotificationType.Alert))
					{
						builder.setTicker(tickerText);

						if (!NotificationHandler.getInstance().notificationNeedsBigStyle())
						{
							builder.setContentTitle(contentTitle == null ? appName : contentTitle);
							builder.setContentText(contentText);
						}
						else
						{
							NotificationCompat.BigTextStyle style = new NotificationCompat.BigTextStyle();
							style.bigText(contentText);
							style.setBigContentTitle(contentTitle == null ? appName : contentTitle);
							builder.setStyle(style);
						}
					}
					else
					{
						Debug.warning(CommonDefines.NOTIFICATION_TAG, "Alerts off. No Notification type was set");
					}
					Notification notification = builder.build();
					notificationManager.notify(notificationTag, 0, notification);

				}
				else
				{
					Debug.warning(CommonDefines.NOTIFICATION_TAG, "No data for content text to show in notification bar! key : " + keyMap.getString(NotificationDefines.CONTENT_TEXT));
					if (Debug.ENABLED)
					{
						builder.setContentText("No Message!!!");
						notificationManager.notify(notificationTag, 0, builder.build());
					}
				}

			}
			catch (JSONException e)
			{
				e.printStackTrace();
			}

		}

		if (isAppRunning)
		{

			if (isRemoteNotification)
			{
				NativePluginHelper.sendMessage(UnityDefines.Notification.DID_RECEIVE_REMOTE_NOTIFICATION, formattedNotificationString);
			}
			else
			{
				NativePluginHelper.sendMessage(UnityDefines.Notification.DID_RECEIVE_LOCAL_NOTIFICATION, formattedNotificationString);
			}
		}
	}

	JSONObject getFormattedNotification(JSONObject notificationData, JSONObject keyMap)
	{
		JSONObject formattedNotification = null;

		try
		{

			formattedNotification = new JSONObject(notificationData, JSONUtility.getKeys(notificationData));

			formattedNotification.put(keyMap.getString(NotificationDefines.FIRE_DATE), System.currentTimeMillis());

			if (formattedNotification.has(keyMap.getString(NotificationDefines.USER_INFO)))
			{
				try
				{
					String userInfoString = formattedNotification.getString(keyMap.getString(NotificationDefines.USER_INFO));
					formattedNotification.remove(keyMap.getString(NotificationDefines.USER_INFO));
					formattedNotification.put(keyMap.getString(NotificationDefines.USER_INFO), new JSONObject(userInfoString));
				}
				catch (Exception e)
				{
					Debug.error(CommonDefines.NOTIFICATION_TAG, "UserInfo Data should be a dictionary");
					Debug.error(CommonDefines.NOTIFICATION_TAG, e.getMessage());
				}
			}

		}
		catch (JSONException e)
		{
			e.printStackTrace();
			formattedNotification = new JSONObject();
		}

		return formattedNotification;

	}

	Bitmap getCustomLargeIconBitmap(String largeIconName)
	{
		if (!StringUtility.isNullOrEmpty(largeIconName))
		{
			Bitmap largeIcon = null;
			try
			{
				Debug.log(CommonDefines.NOTIFICATION_TAG, "largeIconUri : file path [Should be in assets folder] " + CommonDefines.PROJECT_ASSETS_FOLDER + largeIconName);

				largeIcon = BitmapFactory.decodeStream(context.getAssets().open(CommonDefines.PROJECT_ASSETS_FOLDER + largeIconName));
			}
			catch (FileNotFoundException e)
			{
				e.printStackTrace();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}

			return largeIcon;
		}
		else
		{
			return null;
		}
	}

	void PlayCustomNotificationSound(String customSoundName)
	{
		Debug.log(CommonDefines.NOTIFICATION_TAG, "customSoundName file path [Should be in assets folder] " + CommonDefines.PROJECT_ASSETS_FOLDER + customSoundName);

		try
		{
			AssetFileDescriptor assetFileDescriptor = context.getAssets().openFd(CommonDefines.PROJECT_ASSETS_FOLDER + customSoundName);

			//Start media player directly.
			mediaPlayer = new MediaPlayer();
			mediaPlayer.setDataSource(assetFileDescriptor.getFileDescriptor(), assetFileDescriptor.getStartOffset(), assetFileDescriptor.getLength());
			mediaPlayer.prepare();
			mediaPlayer.start();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}
}
