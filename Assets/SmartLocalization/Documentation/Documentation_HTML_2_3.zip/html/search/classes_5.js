var searchData=
[
  ['iautomatictranslator',['IAutomaticTranslator',['../interface_smart_localization_1_1_editor_1_1_i_automatic_translator.html',1,'SmartLocalization::Editor']]],
  ['iosstorepresencegenerator',['IOSStorePresenceGenerator',['../class_smart_localization_1_1_editor_1_1_i_o_s_store_presence_generator.html',1,'SmartLocalization::Editor']]]
];
