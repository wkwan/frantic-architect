var class_smart_localization_1_1_localized_audio_source =
[
    [ "audioClip", "class_smart_localization_1_1_localized_audio_source.html#aad33be5030377db77592d918ba86b677", null ],
    [ "localizedKey", "class_smart_localization_1_1_localized_audio_source.html#abce0b4fbdc0ebc8f89348b997fd5e248", null ]
];