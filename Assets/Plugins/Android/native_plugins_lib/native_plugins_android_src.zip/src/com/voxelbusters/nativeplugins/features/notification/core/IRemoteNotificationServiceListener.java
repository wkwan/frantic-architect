package com.voxelbusters.nativeplugins.features.notification.core;

public interface IRemoteNotificationServiceListener
{
	void onReceivingRegistrationID(String registrationID);

	void onUnRegistration(String status);
}
