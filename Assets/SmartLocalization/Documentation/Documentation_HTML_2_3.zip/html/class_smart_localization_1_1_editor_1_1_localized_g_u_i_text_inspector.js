var class_smart_localization_1_1_editor_1_1_localized_g_u_i_text_inspector =
[
    [ "OnInspectorGUI", "class_smart_localization_1_1_editor_1_1_localized_g_u_i_text_inspector.html#a4b4cb46e7179d1c4ec4a81069a354549", null ]
];