var searchData=
[
  ['semi_5fcolon',['SEMI_COLON',['../class_smart_localization_1_1_editor_1_1_c_s_v_parser.html#ab680cf711edfb43eefcb749e7bf3a76faa0eeda2a96e4680733b9c6026c1dba7a',1,'SmartLocalization.Editor.CSVParser.SEMI_COLON()'],['../namespace_smart_localization_1_1_editor.html#a5781827f1d50ce14c62369d109fa27e9aa0eeda2a96e4680733b9c6026c1dba7a',1,'SmartLocalization.Editor.SEMI_COLON()']]]
];
