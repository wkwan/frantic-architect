var searchData=
[
  ['delimiter',['Delimiter',['../class_smart_localization_1_1_editor_1_1_c_s_v_parser.html#ab680cf711edfb43eefcb749e7bf3a76f',1,'SmartLocalization::Editor::CSVParser']]]
];
