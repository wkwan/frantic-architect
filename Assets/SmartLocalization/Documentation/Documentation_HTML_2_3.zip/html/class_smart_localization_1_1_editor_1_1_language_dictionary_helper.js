var class_smart_localization_1_1_editor_1_1_language_dictionary_helper =
[
    [ "AddNewKeyPersistent", "class_smart_localization_1_1_editor_1_1_language_dictionary_helper.html#a386d8ef4505eb6161050824ee62e468f", null ],
    [ "AddNewKeyPersistent", "class_smart_localization_1_1_editor_1_1_language_dictionary_helper.html#ab9b6e1fbebb5bb66f0f9de9faaeb8224", null ]
];