var searchData=
[
  ['englishname',['englishName',['../class_smart_localization_1_1_smart_culture_info.html#a089a5441263292f81bf4ff2c557fecb1',1,'SmartLocalization::SmartCultureInfo']]]
];
