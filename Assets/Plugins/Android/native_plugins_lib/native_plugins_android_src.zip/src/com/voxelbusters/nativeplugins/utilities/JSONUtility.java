package com.voxelbusters.nativeplugins.utilities;

import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;

import com.voxelbusters.nativeplugins.defines.CommonDefines;

public class JSONUtility
{
	public static JSONObject getJSONfromBundle(Bundle bundle)
	{
		JSONObject json = new JSONObject();

		//Get all keys and create json
		Set<String> keys = bundle.keySet();

		for (String eachKey : keys)
		{
			Object eachVal = bundle.get(eachKey);

			try
			{
				json.put(eachKey, eachVal);
			}
			catch (JSONException e)
			{
				e.printStackTrace();
				Debug.error(CommonDefines.JSON_UTILS_TAG, "Exception while entering key " + eachKey);
			}
		}
		return json;
	}

	public static String[] getKeys(JSONObject jsonData)
	{

		JSONArray jsonArray = jsonData.names();
		String[] keys = new String[jsonArray.length()];

		for (int i = 0, count = jsonArray.length(); i < count; i++)
		{
			try
			{
				keys[i] = jsonArray.getString(i);
			}
			catch (JSONException e)
			{
				e.printStackTrace();
			}
		}

		return keys;
	}
}
