var searchData=
[
  ['metafileending',['metaFileEnding',['../class_smart_localization_1_1_editor_1_1_localization_workspace.html#a32e01ed29c641fe49a50ccb844aa861e',1,'SmartLocalization::Editor::LocalizationWorkspace']]]
];
