var searchData=
[
  ['metafileending',['metaFileEnding',['../class_smart_localization_1_1_editor_1_1_localization_workspace.html#a32e01ed29c641fe49a50ccb844aa861e',1,'SmartLocalization::Editor::LocalizationWorkspace']]],
  ['microsoftautomatictranslator',['MicrosoftAutomaticTranslator',['../class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html#a727bc2543f729338d6a9560b61a8d3ec',1,'SmartLocalization::Editor::MicrosoftAutomaticTranslator']]],
  ['microsoftautomatictranslator',['MicrosoftAutomaticTranslator',['../class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html',1,'SmartLocalization::Editor']]]
];
