var searchData=
[
  ['translatelanguagewindow',['TranslateLanguageWindow',['../class_smart_localization_1_1_editor_1_1_translate_language_window.html',1,'SmartLocalization::Editor']]]
];
