package com.voxelbusters.nativeplugins.features.billing.core;

import java.util.ArrayList;

import org.json.JSONObject;

public interface IBillingServiceListener
{
	void onSetupFinished(Boolean isBillingAvialable);

	void onRequestProductsFinished(ArrayList<JSONObject> productDetails);

	void onRequestProductsFailed(String error);

	void onTransactionFinished(ArrayList<JSONObject> transactionDetails);

}
