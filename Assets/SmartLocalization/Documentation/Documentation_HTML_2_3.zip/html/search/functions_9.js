var searchData=
[
  ['microsoftautomatictranslator',['MicrosoftAutomaticTranslator',['../class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html#a727bc2543f729338d6a9560b61a8d3ec',1,'SmartLocalization::Editor::MicrosoftAutomaticTranslator']]]
];
