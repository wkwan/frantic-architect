var searchData=
[
  ['nativename',['nativeName',['../class_smart_localization_1_1_smart_culture_info.html#aabd10ea163d66641540d09ed1e24025f',1,'SmartLocalization::SmartCultureInfo']]]
];
