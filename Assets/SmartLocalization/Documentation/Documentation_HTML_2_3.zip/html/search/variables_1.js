var searchData=
[
  ['defaultlanguage',['defaultLanguage',['../class_smart_localization_1_1_language_manager.html#ac0b8d2d1530ac8066eb9f11c7ee711de',1,'SmartLocalization::LanguageManager']]]
];
