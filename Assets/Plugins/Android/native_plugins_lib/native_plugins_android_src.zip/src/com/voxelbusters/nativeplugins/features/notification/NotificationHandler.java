package com.voxelbusters.nativeplugins.features.notification;

import org.json.JSONArray;
import org.json.JSONException;

import android.app.NotificationManager;
import android.content.Context;

import com.voxelbusters.nativeplugins.NativePluginHelper;
import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.features.notification.core.NotificationDefines;
import com.voxelbusters.nativeplugins.utilities.ApplicationUtility;
import com.voxelbusters.nativeplugins.utilities.Debug;

public class NotificationHandler
{
	public enum NotificationType
	{
		None, Badge, Sound, BadgeAndSound, Alert//Badge no option yet.
	}

	// Create singleton instance
	private static NotificationHandler	INSTANCE;

	public static NotificationHandler getInstance()
	{
		if (INSTANCE == null)
		{
			INSTANCE = new NotificationHandler();
		}
		return INSTANCE;
	}

	String[]	senderIds;

	int			notificationType;

	boolean		needsBigStyle;

	// Make constructor private for making singleton interface
	private NotificationHandler()
	{
		notificationType = NotificationType.BadgeAndSound.ordinal() | NotificationType.Alert.ordinal();
	}

	public void initialize(String senderIdListJson, String customKeysForNotification, boolean needsBigStyleFormat, boolean useCustomIcon)
	{

		try
		{
			JSONArray jsonArray = new JSONArray(senderIdListJson);
			senderIds = new String[jsonArray.length()];
			for (int i = 0; i < jsonArray.length(); i++)
			{
				senderIds[i] = (String) jsonArray.get(i);
			}

			//Updating custom keys if any for  notification
			NotificationDefines.saveConfigInfo(NativePluginHelper.getCurrentContext(), customKeysForNotification, useCustomIcon);

		}
		catch (JSONException e)
		{
			e.printStackTrace();
			Debug.error(CommonDefines.NOTIFICATION_TAG, "Unable to parse senderIDList!");
		}

		needsBigStyle = needsBigStyleFormat;

	}

	public void setNotificationType(int type)
	{
		notificationType = type;
	}

	public boolean hasNotificationType(NotificationType type)
	{
		boolean hasType = false;

		if ((notificationType & type.ordinal()) > 0)
		{
			hasType = true;
		}
		else if ((notificationType == 0) && (type.ordinal() == 0))//For case zero
		{
			hasType = true;
		}
		else
		{
			hasType = false;
		}

		return hasType;
	}

	public boolean notificationNeedsBigStyle()
	{
		return needsBigStyle;
	}

	//For local notifications

	public void scheduleLocalNotification(String jsonInfo)
	{
		LocalNotification.scheduleLocalNotification(NativePluginHelper.getCurrentContext(), jsonInfo);
	}

	public void cancelLocalNotification(String notificationID)
	{
		//This should cancel notification with notificationID id 
		LocalNotification.cancelNotification(NativePluginHelper.getCurrentContext(), notificationID);
	}

	public void cancelAllLocalNotifications()
	{
		//This should cancel all scheduled notifications
		LocalNotification.cancelAllNotifications(NativePluginHelper.getCurrentContext());
	}

	public void clearAllNotifications()
	{
		//This should clear  all scheduled notifications in the notification bar
		NotificationManager notificationManager = (NotificationManager) ApplicationUtility.getSystemService(NativePluginHelper.getCurrentContext(), Context.NOTIFICATION_SERVICE);
		notificationManager.cancelAll();
	}

	//For remote notifications
	public void registerRemoteNotifications()
	{
		if (senderIds.length == 0)
		{
			Debug.error("NotificationHandler.registerRemoteNotifications", "Add senderId's in the NP Settings");
		}
		else
		{
			RemoteNotification.getInstance().registerForRemoteNotifications(senderIds);
		}
	}

	public void unregisterRemoteNotifications()
	{
		RemoteNotification.getInstance().unregisterForRemoteNotifications();
	}

}
