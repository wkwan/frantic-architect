package com.voxelbusters;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.defines.Keys;
import com.voxelbusters.nativeplugins.utilities.ApplicationUtility;
import com.voxelbusters.nativeplugins.utilities.Debug;

// This class is to get the launch notification info.
public class NotificationLauncher extends Activity
{
	@Override
	protected void onCreate(Bundle paramBundle)
	{
		super.onCreate(paramBundle);
		AddUI();//For testing
	}

	void AddUI()
	{
		Button button = new Button(this);

		button.setText("Launch Main Activity");
		button.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					//Launch main activity
					Class<?> launcher = ApplicationUtility.GetLauncherActivity(NotificationLauncher.this);

					Intent intent = new Intent(NotificationLauncher.this, launcher);
					intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);

					startActivity(intent);

					Debug.log(CommonDefines.NOTIFICATION_TAG, getIntent().getStringExtra(Keys.Notification.NOTIFICATION_PAYLOAD));//We can save this in prefs and tell the app that with this app got launched.

					finish();
					//Save launched notification here
				}
			});

		setContentView(button);

	}
}
