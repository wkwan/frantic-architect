var class_smart_localization_1_1_editor_1_1_editor_thread_queuer =
[
    [ "QueueOnMainThread", "class_smart_localization_1_1_editor_1_1_editor_thread_queuer.html#a5f173e725d25c87c59459e71e5e9cc1b", null ],
    [ "Instance", "class_smart_localization_1_1_editor_1_1_editor_thread_queuer.html#a197099810f5ff8e68a0b3f1d2796d22e", null ]
];