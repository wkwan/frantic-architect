var searchData=
[
  ['currentlyloadedculture',['CurrentlyLoadedCulture',['../class_smart_localization_1_1_language_manager.html#a2c4d01902fbdd4b848baadecae5d6407',1,'SmartLocalization::LanguageManager']]]
];
