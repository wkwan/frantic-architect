package com.voxelbusters.nativeplugins.features.notification;

import org.json.JSONException;
import org.json.JSONObject;

import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.features.notification.core.NotificationDefines;
import com.voxelbusters.nativeplugins.utilities.Debug;

public class LocalNotificationInfo
{

	String		id;
	String		tickerText;
	String		contentTitle;
	String		contentText;
	float		fireAfterSeconds;
	JSONObject	userInfo;
	String		tag;

	public LocalNotificationInfo(String jsonInfo) throws JSONException
	{
		//Parse the json string here.
		JSONObject json = new JSONObject(jsonInfo);
		tickerText = json.getString(NotificationDefines.GetCustomKey(NotificationDefines.TICKER_TEXT));
		contentTitle = json.getString(NotificationDefines.GetCustomKey(NotificationDefines.CONTENT_TITLE));
		contentText = json.getString(NotificationDefines.GetCustomKey(NotificationDefines.CONTENT_TEXT));
		tag = json.getString(NotificationDefines.GetCustomKey(NotificationDefines.TAG));
		userInfo = json.getJSONObject(NotificationDefines.GetCustomKey(NotificationDefines.USER_INFO));

		//Id is included in userinfo dict
		id = userInfo.getString(NotificationDefines.GetCustomKey(NotificationDefines.NOTIFICATION_IDENTIFIER));

		long timeInMillis = json.getLong(NotificationDefines.GetCustomKey(NotificationDefines.FIRE_DATE));
		fireAfterSeconds = (timeInMillis - System.currentTimeMillis()) / 1000;//Fire time converted to seconds
        
        Debug.log(CommonDefines.NOTIFICATION_TAG, "Scheduling firing after : " + fireAfterSeconds + " Secs...");

	}

	public JSONObject getNotificationData()
	{
		JSONObject json = new JSONObject();

		try
		{
			json.put(NotificationDefines.GetCustomKey(NotificationDefines.NOTIFICATION_IDENTIFIER), id);
			json.put(NotificationDefines.GetCustomKey(NotificationDefines.TICKER_TEXT), tickerText);
			json.put(NotificationDefines.GetCustomKey(NotificationDefines.CONTENT_TITLE), contentTitle);
			json.put(NotificationDefines.GetCustomKey(NotificationDefines.CONTENT_TEXT), contentText);
			json.put(NotificationDefines.GetCustomKey(NotificationDefines.USER_INFO), userInfo);
			json.put(NotificationDefines.GetCustomKey(NotificationDefines.TAG), tag);
			json.put(NotificationDefines.GetCustomKey(NotificationDefines.FIRE_DATE), fireAfterSeconds);
		}
		catch (JSONException e)
		{
			e.printStackTrace();
			Debug.error(CommonDefines.NOTIFICATION_TAG, "Error parsing creating json in localNotification");
		}

		return json;
	}

}
