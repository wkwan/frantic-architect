var searchData=
[
  ['objecttype',['ObjectType',['../class_smart_localization_1_1_localized_object.html#a1a9d88fc5e2f00b95fbc1b0b7400d687',1,'SmartLocalization::LocalizedObject']]],
  ['overridelocalizedobject',['OverrideLocalizedObject',['../class_smart_localization_1_1_localized_object.html#af8c572c35922ef1ddd15a339102dadea',1,'SmartLocalization::LocalizedObject']]],
  ['overrideobjectlanguagecode',['OverrideObjectLanguageCode',['../class_smart_localization_1_1_localized_object.html#a340e6ab51e19615055d1970b0f78d807',1,'SmartLocalization::LocalizedObject']]]
];
