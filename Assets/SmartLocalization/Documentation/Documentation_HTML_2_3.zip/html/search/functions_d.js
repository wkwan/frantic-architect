var searchData=
[
  ['texturesfolderpath',['TexturesFolderPath',['../class_smart_localization_1_1_language_runtime_data.html#a6ffe0435e96afcc36e80678b21dd3fad',1,'SmartLocalization::LanguageRuntimeData']]],
  ['translatetext',['TranslateText',['../interface_smart_localization_1_1_editor_1_1_i_automatic_translator.html#a9dc6bf513b6a5da5e8d658129e6e8e13',1,'SmartLocalization.Editor.IAutomaticTranslator.TranslateText()'],['../class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html#aed778e2e982b3f021b4f42139912af13',1,'SmartLocalization.Editor.MicrosoftAutomaticTranslator.TranslateText()']]],
  ['translatetextarray',['TranslateTextArray',['../interface_smart_localization_1_1_editor_1_1_i_automatic_translator.html#a8c6405dc510671d5ed92099456f0e42c',1,'SmartLocalization.Editor.IAutomaticTranslator.TranslateTextArray()'],['../class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html#a50a6db51a3140bf1b5dc3186712bcf1a',1,'SmartLocalization.Editor.MicrosoftAutomaticTranslator.TranslateTextArray()']]],
  ['translatetextarrayeventhandler',['TranslateTextArrayEventHandler',['../namespace_smart_localization_1_1_editor.html#a9b999109c51fe2a6b282af2f66d30215',1,'SmartLocalization::Editor']]],
  ['translatetexteventhandler',['TranslateTextEventHandler',['../namespace_smart_localization_1_1_editor.html#a2646dd5e6439e3316f1f42e359e1f2f9',1,'SmartLocalization::Editor']]]
];
