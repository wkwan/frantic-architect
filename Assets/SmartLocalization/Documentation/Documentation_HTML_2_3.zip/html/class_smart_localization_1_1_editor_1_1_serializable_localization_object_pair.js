var class_smart_localization_1_1_editor_1_1_serializable_localization_object_pair =
[
    [ "SerializableLocalizationObjectPair", "class_smart_localization_1_1_editor_1_1_serializable_localization_object_pair.html#ab076f1a075d487eef843e2a5f87acc63", null ],
    [ "SerializableLocalizationObjectPair", "class_smart_localization_1_1_editor_1_1_serializable_localization_object_pair.html#a47bb57de306c85b826d1798dd0e3f48b", null ],
    [ "changedValue", "class_smart_localization_1_1_editor_1_1_serializable_localization_object_pair.html#a79eec6adf5380170fa4f81b672f619c6", null ],
    [ "keyValue", "class_smart_localization_1_1_editor_1_1_serializable_localization_object_pair.html#a9b664bd72a2254dd20cc528f81ab8162", null ]
];