var class_smart_localization_1_1_editor_1_1_smart_localization_window =
[
    [ "DrawAutoTranslateOptions", "class_smart_localization_1_1_editor_1_1_smart_localization_window.html#aadf94e774519d85f0d21e2a9f4ba81d3", null ],
    [ "DrawAvailableLanguageItem", "class_smart_localization_1_1_editor_1_1_smart_localization_window.html#abcf29a2c51481976390269888faaff2b", null ],
    [ "DrawCreateLanguageItem", "class_smart_localization_1_1_editor_1_1_smart_localization_window.html#a8053dcaabde8ab80a2f193c785a71b14", null ],
    [ "DrawSettingsActions", "class_smart_localization_1_1_editor_1_1_smart_localization_window.html#aee3478b251d4f8bf57b7be5e984b4631", null ],
    [ "DrawSettingsItem", "class_smart_localization_1_1_editor_1_1_smart_localization_window.html#aa2fe0506d9a48ac588909e4f0f324bb8", null ],
    [ "DrawStorePresenceActions", "class_smart_localization_1_1_editor_1_1_smart_localization_window.html#a97f240eefc123dc320bf78b3bf15f42a", null ],
    [ "InitializeCultureCollections", "class_smart_localization_1_1_editor_1_1_smart_localization_window.html#a4ce0a11ba689bda34595745a253a483c", null ],
    [ "ShowWindow", "class_smart_localization_1_1_editor_1_1_smart_localization_window.html#a8ebb327330f4ef039c0ba71c1c6682a1", null ],
    [ "automaticTranslator", "class_smart_localization_1_1_editor_1_1_smart_localization_window.html#aced1cddaadfe0cda44430a4ef98d7e6a", null ],
    [ "KeepAuthenticatedSaveKey", "class_smart_localization_1_1_editor_1_1_smart_localization_window.html#ac82909abb031078730235afe1c656da6", null ],
    [ "MicrosoftTranslatorIDSaveKey", "class_smart_localization_1_1_editor_1_1_smart_localization_window.html#a4793efcd1bb254ee67952b9f4a7e2b48", null ],
    [ "MicrosoftTranslatorSecretSaveKey", "class_smart_localization_1_1_editor_1_1_smart_localization_window.html#a31cbb6816e46425ebf7b723808cccd1b", null ],
    [ "translateLanguageWindow", "class_smart_localization_1_1_editor_1_1_smart_localization_window.html#ad9b5254a6711c94390878ae1ad0c5918", null ],
    [ "AvailableCultures", "class_smart_localization_1_1_editor_1_1_smart_localization_window.html#a515334f7223b51789fe4ed8a8cf71366", null ]
];