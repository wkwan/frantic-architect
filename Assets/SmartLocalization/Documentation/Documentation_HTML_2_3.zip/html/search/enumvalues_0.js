var searchData=
[
  ['caret',['CARET',['../class_smart_localization_1_1_editor_1_1_c_s_v_parser.html#ab680cf711edfb43eefcb749e7bf3a76fa3fa4f0392be4af9d316dc092f60ff3ca',1,'SmartLocalization.Editor.CSVParser.CARET()'],['../namespace_smart_localization_1_1_editor.html#a5781827f1d50ce14c62369d109fa27e9a3fa4f0392be4af9d316dc092f60ff3ca',1,'SmartLocalization.Editor.CARET()']]],
  ['comma',['COMMA',['../class_smart_localization_1_1_editor_1_1_c_s_v_parser.html#ab680cf711edfb43eefcb749e7bf3a76fa4d9b3e9fc12849d060371eb65154c751',1,'SmartLocalization.Editor.CSVParser.COMMA()'],['../namespace_smart_localization_1_1_editor.html#a5781827f1d50ce14c62369d109fa27e9a4d9b3e9fc12849d060371eb65154c751',1,'SmartLocalization.Editor.COMMA()']]]
];
