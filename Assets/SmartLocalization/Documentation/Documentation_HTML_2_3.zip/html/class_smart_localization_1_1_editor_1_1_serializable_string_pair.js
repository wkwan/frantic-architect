var class_smart_localization_1_1_editor_1_1_serializable_string_pair =
[
    [ "SerializableStringPair", "class_smart_localization_1_1_editor_1_1_serializable_string_pair.html#a124cf34384f11ccf35d9b6972851023e", null ],
    [ "SerializableStringPair", "class_smart_localization_1_1_editor_1_1_serializable_string_pair.html#a0f36289c3b083fe3d706254717af7d4b", null ],
    [ "changedValue", "class_smart_localization_1_1_editor_1_1_serializable_string_pair.html#a9b61f4b273eacd9102274bf59e3e2bd1", null ],
    [ "originalValue", "class_smart_localization_1_1_editor_1_1_serializable_string_pair.html#a6d0f9ed6906eb818942e8b0d99a8b52a", null ]
];