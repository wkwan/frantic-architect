var searchData=
[
  ['csvdelimiter',['CSVDelimiter',['../namespace_smart_localization_1_1_editor.html#a5781827f1d50ce14c62369d109fa27e9',1,'SmartLocalization::Editor']]]
];
