var class_smart_localization_1_1_editor_1_1_language_import_window =
[
    [ "ShowWindow", "class_smart_localization_1_1_editor_1_1_language_import_window.html#a9ef66f414d8c05cb72879ad4d83cc070", null ],
    [ "chosenCulture", "class_smart_localization_1_1_editor_1_1_language_import_window.html#a85387a02307ef7b0d49c2534d11e892b", null ],
    [ "creationDelegate", "class_smart_localization_1_1_editor_1_1_language_import_window.html#ae96f70928db73ec8cf56915ebf1e6f15", null ],
    [ "delimiter", "class_smart_localization_1_1_editor_1_1_language_import_window.html#adecde97d893db446d796ee0353c5cd67", null ]
];