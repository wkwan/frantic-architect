var searchData=
[
  ['hasinstance',['HasInstance',['../class_smart_localization_1_1_language_manager.html#a6410aaa7fca60f58dcbd96e6fc36b5f3',1,'SmartLocalization::LanguageManager']]],
  ['haskey',['HasKey',['../class_smart_localization_1_1_language_manager.html#a3df527177ecd45fb97103cbfe1599a35',1,'SmartLocalization::LanguageManager']]],
  ['hasstorepresence',['HasStorePresence',['../class_smart_localization_1_1_editor_1_1_android_store_presence_generator.html#ae66e13a2ac98ec3889723531df5d1153',1,'SmartLocalization::Editor::AndroidStorePresenceGenerator']]]
];
