var searchData=
[
  ['rawtextdatabase',['RawTextDatabase',['../class_smart_localization_1_1_language_manager.html#a1db4ebceced81465ac0e7fba9d27d3bf',1,'SmartLocalization::LanguageManager']]],
  ['read',['Read',['../class_smart_localization_1_1_editor_1_1_c_s_v_parser.html#a1363e06885f589b606ea5b88949c065c',1,'SmartLocalization::Editor::CSVParser']]],
  ['readcsv',['ReadCSV',['../class_smart_localization_1_1_editor_1_1_c_s_v_exporter.html#a2dbfa5a760551175f27b4c1acaaee56e',1,'SmartLocalization::Editor::CSVExporter']]],
  ['readfromfile',['ReadFromFile',['../class_smart_localization_1_1_editor_1_1_file_utility.html#acf52a916da78963642ab2705b43d3702',1,'SmartLocalization::Editor::FileUtility']]],
  ['refreshlist',['RefreshList',['../class_smart_localization_1_1_editor_1_1_localized_key_selector.html#a6d29aadd02b186fd633bf9113a188d84',1,'SmartLocalization::Editor::LocalizedKeySelector']]],
  ['removecultureinfo',['RemoveCultureInfo',['../class_smart_localization_1_1_smart_culture_info_collection.html#acc9f4b8d940118f05889c76b7c1a3f02',1,'SmartLocalization::SmartCultureInfoCollection']]],
  ['removeextension',['RemoveExtension',['../class_smart_localization_1_1_editor_1_1_file_utility.html#a6659653033a2617037c427c123d5241d',1,'SmartLocalization::Editor::FileUtility']]],
  ['removewhitespace',['RemoveWhitespace',['../class_smart_localization_1_1_editor_1_1_string_extensions.html#ac155de0a549bebeb182a8b4d23916d34',1,'SmartLocalization::Editor::StringExtensions']]],
  ['renamefilefromresources',['RenameFileFromResources',['../class_smart_localization_1_1_editor_1_1_language_handler_editor.html#a4377e765196d3413a55fd1b6b293b897',1,'SmartLocalization::Editor::LanguageHandlerEditor']]],
  ['resourcesfolderfilepath',['ResourcesFolderFilePath',['../class_smart_localization_1_1_editor_1_1_localization_workspace.html#adc18fcd47cabd100a9c35dabe629362d',1,'SmartLocalization::Editor::LocalizationWorkspace']]],
  ['resourcesfolderfilepathrelative',['ResourcesFolderFilePathRelative',['../class_smart_localization_1_1_editor_1_1_localization_workspace.html#a6012f0fa0a54cdacbbd902adacd846f2',1,'SmartLocalization::Editor::LocalizationWorkspace']]],
  ['resxfileending',['resXFileEnding',['../class_smart_localization_1_1_editor_1_1_localization_workspace.html#a8c06b09a727b9bc7e0499db58b4591c2',1,'SmartLocalization::Editor::LocalizationWorkspace']]],
  ['rootlanguagefilepath',['RootLanguageFilePath',['../class_smart_localization_1_1_editor_1_1_localization_workspace.html#af1722ff34a3204693e664de360add72b',1,'SmartLocalization::Editor::LocalizationWorkspace']]],
  ['rootlanguagename',['rootLanguageName',['../class_smart_localization_1_1_editor_1_1_localization_workspace.html#a1255294ca1f58d212e7283d83c5ca478',1,'SmartLocalization::Editor::LocalizationWorkspace']]]
];
