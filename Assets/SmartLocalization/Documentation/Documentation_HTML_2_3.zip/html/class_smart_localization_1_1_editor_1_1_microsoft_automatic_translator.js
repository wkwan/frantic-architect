var class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator =
[
    [ "MicrosoftAutomaticTranslator", "class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html#a727bc2543f729338d6a9560b61a8d3ec", null ],
    [ "GetAvailableTranslationLanguages", "class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html#a724f1a452fb9a3f7c2d8ac2d00959cdf", null ],
    [ "Initialize", "class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html#ae2917d77fd865d4e5e3428c1e50e9198", null ],
    [ "TranslateText", "class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html#aed778e2e982b3f021b4f42139912af13", null ],
    [ "TranslateTextArray", "class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html#a50a6db51a3140bf1b5dc3186712bcf1a", null ],
    [ "InitializationDidExpire", "class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html#a3484ab7573f015415a4ab4921f45a850", null ],
    [ "IsInitialized", "class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html#ab3f8fbf1025d29faedd84325f0b4518b", null ],
    [ "IsInitializing", "class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html#a4131918c50f350eb7328101576575f45", null ]
];